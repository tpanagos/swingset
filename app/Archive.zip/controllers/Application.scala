package controllers

import java.io._
import play.api._
import play.api.mvc._
import play.api.data._
import play.api.data.Forms._
import play.api.data.format.Formats._
import org.activiti.engine
import org.activiti.engine._
import org.activiti.engine.runtime
import org.activiti.engine.form
import org.activiti.engine.task
import models._
import views.html.helper.FieldElements
import play.data.DynamicForm

object Application extends Controller {

		private var processEngine: ProcessEngine = null
		private var repositoryService: RepositoryService = null
		private var runtimeService: RuntimeService = null
		private var taskService: TaskService = null
		private var formService: FormService = null
		private var formData: org.activiti.engine.form.TaskFormData = null
		private	var processInstance: org.activiti.engine.runtime.ProcessInstance = null
		private var currentTask: org.activiti.engine.task.Task = null
		private var startFormData: org.activiti.engine.form.StartFormData = null
		private var message: String = ""
		private var lastTrace: String = ""
		private var newTrace: String = ""
		
		private val processName: String = "registrationRequest" /* if this name is wrong, you will get a generic exception from the index fn: play.core.ActionInvoker$$anonfun$receive$1$$anon$1: Execution exception [[NullPointerException: null]]*/
		private val processFile: String = "registration.bpmn"
		//private val processName: String = "vacationRequest"
		//private val processFile: String = processName + ".bpmn20.xml"		  
		private val processPath: String = "/Users/tim/Documents/dev/workspace/signupWizard/lib/" + processFile
		lazy private val processLabel: String = repositoryService.createProcessDefinitionQuery.latestVersion.processDefinitionKey(processName).singleResult.getName 
		lazy private val processDescription: String = repositoryService.createProcessDefinitionQuery.latestVersion.processDefinitionKey(processName).singleResult.getDescription
		
	  var dynTaskForm = new DynamicForm
	  initializeProcessEngine

	  
	  /**
	   * Action to respond to a GET from the / URL
	  */	  	  	  
      def index = Action {
    	  Ok(views.html.index("Welcome to CloudPointe", "start"))
      }   
		
	  /**
	   * Action to respond to a GET from the /start URL
	   * 
	   */
	  def start = Action { 
				deployProcess
			try {
				Logger.info("Initializing Activiti Process " + processName + ".")
				val processDef = repositoryService.createProcessDefinitionQuery.latestVersion.processDefinitionKey(processName).singleResult
				if (processDef != null) {
					startFormData = formService.getStartFormData(processDef.getId)
					} 
				else {throw new IllegalArgumentException(processName + " is not a recognized Process Name.")}
				//message = "Welcome to the " + processLabel + " Process<br/>This process will " + processDescription + "."   
				Logger.info("Success: Initializing Activiti Process " + processName + ".")
				Ok(views.html.start(processLabel, startFormData, dynTaskForm)) 				
			} catch {
				case e: ActivitiException => {
					newTrace = e.getStackTraceString					
					Logger.error("Activiti Failure: Initializing Activiti Process " + processName + ".")
					Logger.error(e.getMessage)
					Logger.error(newTrace)
				    BadRequest(views.html.error(traceContent)).withSession("trace" -> newTrace) 
				}
				case e: Exception => {
					newTrace = e.getStackTraceString
					Logger.error("Failure: Initializing Activiti Process " + processName + ".")	
					Logger.error(e.getMessage)
					Logger.error(newTrace)
				    BadRequest(views.html.error(traceContent)).withSession("trace" -> newTrace) 
				}
			} finally {

					
			}
	  }
		
	 /**
	 * Helper for index Action
	 */
	  def traceContent = {
		  if (lastTrace != "") {
			  if (lastTrace == newTrace) {
				  //Logger.info("here1")
				  "Trace Repeated<br/>" + newTrace
			  } else {
				  //Logger.info("here2")
				  "Trace Changed<br/>New Trace:<br/>" + newTrace + "<br/>Old Trace:<br/>" + lastTrace			        	  
			  }        	
		  } else {
			  //Logger.info("here3")
			  "Trace New<br/>" + newTrace
		  }
	  }
	  
	  /**
	   * Handle the POST 'starting process workflow form' submission 
	   * 
	   */
	  def startHandle = Action { implicit request =>
		  val body: AnyContent = request.body
		  var textBody: Map[String,Seq[String]] = null
		  body.asFormUrlEncoded match {
			  case Some(x) => textBody = x
			  case None => Logger.info("no response body")
		  }
		  /* the line below creates a new map which automatically transforms the Value from a List to a single String*/
		  //val stringForm: Map[String, String] = textBody.mapValues { (x:Seq[String]) => x(0)}    
		  /* the line below creates a new map which automatically transforms the Key to remove the data[] and the Value from a List to a single String */
		  val stringFormMap: Map[String, String] = textBody map { (x:(String, Seq[String])) => (x._1.replace("data[","").replace("]","") , x._2(0))} 	    		    
		  Logger.info("xfrmed password " + stringFormMap.getOrElse("password", "bogus"))
		  Logger.info(stringFormMap.mkString)
	
		  var variables = new java.util.HashMap[String, Object]
		  /* pass through the Form results and add each value to the variables HashMap */
		  for(i <- stringFormMap)
			  variables.put(i._1, i._2.asInstanceOf[AnyRef]) 
			  
		  Logger.info(variables.toString)
		  /* start a process instance and pass the values supplied as the starting parameters */
		  processInstance = runtimeService.startProcessInstanceByKey(processName, variables)
		  message += "<br/>Task Data Begin: " + variables.toString
		  
		  /* we need to check because there may be a start without any steps */
		  val numTasks = taskService.createTaskQuery.processInstanceId(processInstance.getId()).count
		  if ((numTasks) > 0) {
		  	  /* still more tasks to be done */
		  	  Logger.info("The Process with ID " + processInstance.getId() + " has " + numTasks + " more Task to complete.")
			  Redirect(routes.Application.next)	   		  	
		  } else {
			  Redirect(routes.Application.last)	  		  	
		  } 
	  }
	  	  
	  /**
	   * Action to respond to a GET from the /next URL
	  */	  	  	  
      def next = Action {
    	  currentTask = processEngine.getTaskService.createTaskQuery()
    			  .processInstanceId(processInstance.getId())
    			  .singleResult()
          message += "<br/>Starting Task Name: " + currentTask.getName()
	      message += "<br/>Starting Task Id: " + currentTask.getId() + "<br/>"
	      formData = formService.getTaskFormData(currentTask.getId())
	      message += repositoryService.createProcessDefinitionQuery.latestVersion.processDefinitionKey(processName).singleResult.getId
    	  //Ok(views.html.next(message, formData, dynTaskForm))
    	  				Ok(views.html.modal("welcome","next")) 
      }     
      
	  /**
	   * Handle the POST 'next process workflow form' submission 
	  */
	  def nextHandle = Action { implicit request =>
		  val body: AnyContent = request.body
		  var textBody: Map[String,Seq[String]] = null
		  body.asFormUrlEncoded match {
			  case Some(x) => textBody = x
			  case None => Logger.info("no response body")
		  }
		  /* the line below creates a new map which automatically transforms the Value from a List to a single String*/
		  //val stringForm: Map[String, String] = textBody.mapValues { (x:Seq[String]) => x(0)}    
		  /* the line below creates a new map which automatically transforms the Key to remove the data[] and the Value from a List to a single String */
		  val stringFormMap: Map[String, String] = textBody map { (x:(String, Seq[String])) => (x._1.replace("data[","").replace("]","") , x._2(0))} 	    		    
		  //Logger.info(stringFormMap.mkString)
	
		  var variables = new java.util.HashMap[String, Object]

				  /* pass through the Form results and add each value to the variables HashMap */
				  for(i <- stringFormMap){ 
					  variables.put(i._1, i._2.asInstanceOf[AnyRef]) 
				  }
		  Logger.info(variables.toString)
		  taskService.complete(currentTask.getId, variables);  
		  message += "The task is completed, id is: " + currentTask.getId + "<br/>Task Data Begin: " + variables.toString
		  /* we need to check because there may be a start without any steps */
		  val numTasks = taskService.createTaskQuery.processInstanceId(processInstance.getId()).count
		  if ((numTasks) > 0) {
		  	  /* still more tasks to be done */
		  	  Logger.info("The Process with ID " + processInstance.getId() + " has " + numTasks + " more Task to complete.")
			  Redirect(routes.Application.next)	   		  	
		  } else {
			  Redirect(routes.Application.last)	  		  	
		  } 
     
	  }	  

	  /**
	   * Action to respond to a GET from the /last URL -- this is the end of the process!
	  */	  	  	  
      def last = Action {
          message = "Your " + processLabel + " is complete.<br/>This Process has " + processDescription + ".<br/>Thank you!"
    	  Ok(views.html.error(message))
      }   
      
	  /**
	   * Handle the POST from the redo button  to clear the process context for a rerun
	  */
	  def redoHandle = Action { implicit request =>
		  initializeProcessEngine
		  session.get("trace") match {
			  case Some(x) => lastTrace = x 
			  case None => lastTrace = ""
		  }         
		  Redirect(routes.Application.index)	      
	  }	  	  
	  
	  /**
	   * Action to respond to a GET from the /debug URL
	  */  
	  def debug = Action {
		    Ok(views.html.header(message))  
	  }
	  
	  def initializeProcessEngine { 
		  try {
			  Logger.info("Initializing Activiti ProcessEngine and Services.")
			  processEngine = ProcessEngines.getDefaultProcessEngine()
			  //ProcessEngines.init();
			  repositoryService = processEngine.getRepositoryService()
			  runtimeService = processEngine.getRuntimeService()   
			  taskService = processEngine.getTaskService() 
			  formService = processEngine.getFormService()       
		  } catch {
		  case e: Exception => {
			  Logger.error("Failure: Initializing Activiti ProcessEngine and Services.")			    
			  Logger.error(e.getMessage())
			  return
		  } 
		  } finally {

		  }
		  Logger.info("Success: Initializing Activiti ProcessEngine and Services.")
	  }
	  
	  def deployProcess { 
		var inputStream: java.io.FileInputStream = null  
	  	try {
			  Logger.info("Deploying process from " + processFile + ".")
			  /* try to open the Process File and deploy it*/
			  inputStream = new FileInputStream(processPath)
			  repositoryService.createDeployment()
				  .addInputStream(processFile, inputStream)  //the name of the resource matters: must be the filename?
				  .deploy()				
		  } catch {
		  case e1: IOException => {
				  Logger.error("File I/O Failure: Deploying process from " + processPath + ".")
				  Logger.error(e1.getMessage() + "<br/>" + e1.getStackTraceString)
				  return
			  }
		  case e2: ActivitiException => {
				  Logger.error("Activiti Failure: Deploying process from " + processFile + ".")
				  Logger.error(e2.getMessage() + "<br/>" + e2.getStackTraceString)
				  return
			  }
		  case e: Exception => {
				  Logger.error("Failure: Deploying process from " + processFile + ".")
				  Logger.error(e.getMessage() + "<br/>" + e.getStackTraceString)
				  return
			  }
		  } finally {
			  	if (inputStream !=null) inputStream.close
		  }
		  Logger.info("Success: Deploying process from " + processFile + ".")
		}
}